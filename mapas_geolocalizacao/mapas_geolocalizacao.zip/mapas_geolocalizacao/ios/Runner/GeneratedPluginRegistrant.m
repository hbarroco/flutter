//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <geolocator/GeolocatorPlugin.h>
#import <google_maps_flutter/GoogleMapsPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [GeolocatorPlugin registerWithRegistrar:[registry registrarForPlugin:@"GeolocatorPlugin"]];
  [FLTGoogleMapsPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTGoogleMapsPlugin"]];
}

@end
