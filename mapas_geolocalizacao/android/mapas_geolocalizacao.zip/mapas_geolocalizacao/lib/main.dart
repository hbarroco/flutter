import 'package:flutter/material.dart';

import 'Home.dart';

void main(){
  runApp(MaterialApp(
    title: "Mapas e Geolocalização",
    home: Home(),
  ));
}